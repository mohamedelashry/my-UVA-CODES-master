print ("May 29, 2013 Wednesday")
